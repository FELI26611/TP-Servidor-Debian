#  TRABAJO PRACTICO COMPUTACION APLICADA

### Participantes
# Felipe Erasun

#Contenido
- /root (comprimido)
- /etc (comprimido)
-/opt (comprimido)
-/proc/particion (comprimido)
-/www-dir (comprimido)
- backup /www-dir
- /var (spliteado)
## Scripts Desarrollados 
- /opt/scripts/backup-full.sh


